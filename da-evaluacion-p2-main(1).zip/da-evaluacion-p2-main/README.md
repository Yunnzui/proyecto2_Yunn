# Proyecto Final React (Desarrollo de Aplicaciones)

Se construira un proyecto en ReactJS esta guia nos lleva paso a paso en como realizar la instalacion de los archivos de forma local en nuestros equipos.

Se cargaran 3 proyectos este es el #2 y estos son los pasos de la instalacion:

- Este es el proyecto #2 de React y ya esta pre-armado hay que instalarlo de manera local en nuestro equipo, ya terminando los requerimientos hay que subir el proyecto a un repositorio creado por el alumno a una rama, la nomenclatura de la rama sera ### add-examen2-nombre-alumno.
- Se les concederan los permisos para acceder a los repositorios seleccionados ya sea examen #1, examen #2 y examen #3.

## Pasos para la Instalacion

Para la instalacion de la aplicacion en React en forma local es de la siguiente manera.

- Crear un repositorio personal que es donde se alojara la aplicacion a entregar
- Del repositorio seleccionado evaluacion_page2 descargar el archivo .zip cargado.
- Ya descargado en el equipo se debe descomprimir en la carpeta del repositorio personal
- Para hacer la instalacion debemos abrir una consola o directamente en Visual Studio Code

```js
npm install
```

```js
npm run dev
```

- Esto lo que hace es instalar las dependencias necesarias.

# Y listo tu evaluacion ha comenzado
## Exito y esperemos termines.